<?php

defined('_JEXEC') or die('Restricted access');

modAPQuickLaunchHelper::render($params);

?>
