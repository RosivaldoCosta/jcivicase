<?php
/**
 * lost password email text (html)
 * 
 * @package     Tinebase
 * @subpackage  Views
 * @license     http://www.gnu.org/licenses/agpl.html AGPL Version 3
 * @author      Philipp Schuele <p.schuele@metaways.de>
 * @copyright   Copyright (c) 2007-2008 Metaways Infosystems GmbH (http://www.metaways.de)
 * @version     $Id: lostpwMailHtml.php 5446 2008-11-14 07:52:08Z c.weiss@metaways.de $
 *
 * @todo		fill with more text
 */
?>

<h1><?php echo $this->mailTextWelcome ?></h1>
<p><?php echo $this->newPassword ?></p>
