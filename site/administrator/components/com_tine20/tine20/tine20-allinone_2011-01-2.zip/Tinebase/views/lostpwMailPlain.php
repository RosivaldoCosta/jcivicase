<?php
/**
 * lost password email text (plain)
 * 
 * @package     Tinebase
 * @subpackage  Views
 * @license     http://www.gnu.org/licenses/agpl.html AGPL Version 3
 * @author      Philipp Schuele <p.schuele@metaways.de>
 * @copyright   Copyright (c) 2007-2008 Metaways Infosystems GmbH (http://www.metaways.de)
 * @version     $Id: lostpwMailPlain.php 5446 2008-11-14 07:52:08Z c.weiss@metaways.de $
 *
 * @todo		fill with more text
 */
?>

<?php echo $this->mailTextWelcome ?>

<?php echo $this->newPassword ?>
