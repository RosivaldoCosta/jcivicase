<?php
/**
 * Tine 2.0
 * 
 * @package     Addressbook
 * @license     http://www.gnu.org/licenses/agpl.html AGPL Version 3
 * @copyright   Copyright (c) 2010 Metaways Infosystems GmbH (http://www.metaways.de)
 * @author      Lars Kneschke <l.kneschke@metaways.de>
 * @version     $Id: WebDav.php 15929 2010-08-18 13:58:31Z l.kneschke@metaways.de $
 * 
 */

/**
 * class to handle webdav requests for addressbook
 * 
 * @package     Addressbook
 */
class Addressbook_WebDav extends Tinebase_WebDav_Application_Abstract
{
    protected $_modelName = 'Contact';
}