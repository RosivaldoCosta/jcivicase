insert into civicrm_option_value values (null,27,'Unresolved',4,'Unresolved',null,0,null,4,null,0,1,1,null,null,null)
insert into civicrm_option_value values (null,27,'Follow-Ups',5,'Follow-Ups',null,0,null,5,null,0,1,1,null,null,null)
insert into civicrm_option_value values (null,27,'East Side IHIT',6,'East Side IHIT',null,0,null,6,null,0,1,1,null,null,null)
insert into civicrm_option_value values (null,27,'West Side IHIT',7,'West Side IHIT',null,0,null,7,null,0,1,1,null,null,null)
insert into civicrm_option_value values (null,27,'MCT',8,'MCT',null,0,null,8,null,0,1,1,null,null,null)
insert into civicrm_option_value values (null,27,'Frequent Caller',9,'Frequent Caller',null,0,null,9,null,0,1,1,null,null,null)

